package org.example.demo1;

import javafx.application.Application;
import javafx.stage.Stage;

public class Mahasiswa {

    private String nim;
    private String nama;
    private String nilai;
    public Mahasiswa(String nim, String nama, String nilai) {
        this.nim = nim;
        this.nama = nama;
        this.nilai = nilai;
    }

    public String getNim() {
        return nim;
    }

    public String setnim(String nim) {
        return nim;
    }
    public String getNama() {
        return nama;
    }

    public String setNama(String nama) {
        return nama;
    }

    public String getNilai() {
        return nilai;
    }
    public String setNilai(String nilai) {
        return nilai;
    }
}
