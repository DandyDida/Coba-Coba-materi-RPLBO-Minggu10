package org.example.demo1;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class HelloApplication extends Application {

    private static Stage primaryStage;

    @Override
    public void start(Stage stage) throws IOException {
        primaryStage = stage; // Assign the primary stage
        primaryStage.setTitle("Data Mahasiswa Viewer");

        // Load the FXML layout
        Parent root = loadFXML("mahasiswa-view");

        // Set the scene with the loaded FXML
        primaryStage.setScene(new Scene(root));
        primaryStage.show(); // Don't forget to show the stage
    }

    // Utility method to load FXML files
    private static Parent loadFXML(String fxml) {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource(fxml + ".fxml"));
        try {
            return fxmlLoader.load();
        } catch (IOException e) {
            throw new RuntimeException("Failed to load FXML file: " + fxml, e);
        }
    }

    // Dynamically change the scene root
    public static void setRoot(String fxml, boolean isResizable) {
        primaryStage.getScene().setRoot(loadFXML(fxml));
        primaryStage.sizeToScene();
        primaryStage.setResizable(isResizable);
    }

    public static void main(String[] args) {
        launch(); // Launch the JavaFX application
    }
}