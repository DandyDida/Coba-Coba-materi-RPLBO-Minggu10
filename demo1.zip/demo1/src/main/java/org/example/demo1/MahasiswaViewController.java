package org.example.demo1;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;

public class MahasiswaViewController {

    @FXML
    private TextField txtNim, txtNama, txtNilai; // Input fields

    @FXML
    private TableView<Mahasiswa> table; // TableView for displaying data

    @FXML
    private TableColumn<Mahasiswa, String> nim, nama, nilai; // Columns

    @FXML
    private Label lblInfo; // Info label for count or messages

    private ObservableList<Mahasiswa> mahasiswaList = FXCollections.observableArrayList(); // Data source

    @FXML
    public void initialize() {
        // Initialize columns (mapping properties to display)
        nim.setCellValueFactory(data -> new javafx.beans.property.SimpleStringProperty(data.getValue().getNim()));
        nama.setCellValueFactory(data -> new javafx.beans.property.SimpleStringProperty(data.getValue().getNama()));
        nilai.setCellValueFactory(data -> new javafx.beans.property.SimpleStringProperty(data.getValue().getNilai()));

        // Bind data
        table.setItems(mahasiswaList);
    }

    @FXML
    protected void onBtnAddClick() {
        // Validate inputs
        String nim = txtNim.getText();
        String nama = txtNama.getText();
        String nilai = txtNilai.getText();

        if (nim.isEmpty() || nama.isEmpty() || nilai.isEmpty()) {
            lblInfo.setText("Please fill out all fields!");
            return;
        }

        // Add a new Mahasiswa to the list
        mahasiswaList.add(new Mahasiswa(nim, nama, nilai));

        // Clear input fields
        txtNim.clear();
        txtNama.clear();
        txtNilai.clear();

        lblInfo.setText("Student added! Count: " + mahasiswaList.size());
    }

    @FXML
    protected void onBtnHapusClick() {
        // Remove selected Mahasiswa from the list
        Mahasiswa selected = table.getSelectionModel().getSelectedItem();
        if (selected != null) {
            mahasiswaList.remove(selected);
            lblInfo.setText("Student removed! Count: " + mahasiswaList.size());
        } else {
            lblInfo.setText("Please select a student to remove.");
        }
    }

    @FXML
    protected void onBtnSaveFileClick() {
        // Basic save-to-file functionality can be added here
        lblInfo.setText("Save to File not implemented.");
    }

    @FXML
    protected void onBtnCloseClick() {
        // Exit the application
        System.exit(0);
    }
}